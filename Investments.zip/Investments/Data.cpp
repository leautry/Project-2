#include <iostream>
#include <vector>
#include "Data.h"

using namespace std;

Data::Data() {
	Data::m_userPrompts = {
		"Initial Investment Amount: ",
				"Monthly Deposit: ",
				"Annual interest: ",
				"Number of Years: "
	};
};

const vector<string> &Data::getMUserPrompts() const {
	return m_userPromts;
}

double Data::getMInitialInvestAmt() const {
	return m_initialInvestAmt;
}

void Data::setMInitialInvestAmt(double t_initialInvestAmt) {
	m_initialInvestAmt = t_initialInvestAmt;
}

double Data::getMMonthlyDep() const {
	return m_monthlyDep;
}

void Data::setMMonthlyDep(double t_monthlyDep) {
	m_monthlyDep = t_monthlyDep;
}

double Data::getMAnnualInt() const {
	return m_annualInt;
}

void Data::setMAnnualInt(double t_annualInt) {
	m_annualInt = t_annualInt;
}

double Data::getMNumYears() const {
	return m_numYears;
}

void Data::setMNumYears(double t_numYears) {
	m_numYears = t_numYears;
}

void Data::printHeader() {
	cout << string(36, '*') << endl;
	cout << string(12, '*') << "Data Input " << string(12, '*') << endl;
}

void Data::promptUser() {
	vector<double> depositDetails;
	char quitCmd = 'a';

	while (quitCmd != 'q') {

		try {
			depositDetails.clear();
			printHeader();
			depositDetails = inputCapture();

		}

		catch (invalid_argument& except) {
			cin.clear();
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
			cout <<except.what() << endl;
		}

		if (depositDetails.size() == 4 && enterCheck()) {
			setMInitialInvestAmt(depositDetails.at(0));
			setMMonthlyDep(depositDetails.at(1));
			setMAnnualInt(depositDetails.at(2));
			setMNumYears(depositDetails.at(3));

			quitCmd = 'q';
		}
	}
}

vector<double> Data::inputCapture() {
	vector<double> responses;
	vector<string> prompts = getMUserPrompts();

	for (int i = 0; i < prompts.size(); ++i) {
		string promt = prompts.at(i);
		double userInput;
		cout << prompts;
		cin >> userInput;

		if (!cin ||userInput < 0.01) {
			throw invalid_argument("\n\nAlphabetical characters and amounts less than .01 not allowed. \n\n"
					"Please try again. \n\n");
		}

		responses.push_back(userInput);
	}
	return responses;
}


bool Data::enterCheck() {
	cout << "Press enter to continue . . .\n\n\n";
	return cin.get() == '\n';
}
