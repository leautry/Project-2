#include <string>
#include <iostream>
#include "Data.h"
#include "Calculate.h"
#include "Report.h"
#include "Invest.h"

using namespace std;

void startApp() {
	bool restart = true;

	try {
		do {
			Data userDate;
			userData.promptUser();

			Calculate calculate;
			Invest acctWithNoMonthlyDep = calculate.calculateAnnualInvestment(userData);
			Invest acctWithMonthlyDep = calculate.calculateAnnualInvestment(userData, true);

			Report balanceAndInterestReposrt;
			balanceAndInterestReport.reportGenerator(acctWithNoMonthlyDep, acctWithMonthlyDep);

			restart = balanceAndInterestReport.additionalSessionCheck();
		} while (restart);
	}
	catch (runtime_error& except) {
		cout << "Oops! Something went wrong. Exception: " << except.what() << endl;
	}
}

int main() {

	startApp();

	return 0;
}
