
#ifndef AIRGEAD_BANKING_REPORT_H
#define AIRGEAD_BANKING_REPORT_H

#include <vector>
#include "Data.h"
#include "Calculate.h"
#include "Invest.h"

using namespace std;

class Report {
public:
	Report();

	void reportGenerator(Invest &t_dataOne, Invest &dataTwo);

	bool addistionalSessionCheck();

private:
	void printColHeader();

	void annualReport(Invest &t_data);

};

#endif /* AIRGEAD_BANKING_REPORT_H_ */
