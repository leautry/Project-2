
#include "Invest.h"
#include <vector>

using namespace std;


Invest::Invest() {}

const vector<int> &Invest::getMYears() const{
	return m_years;
}

void Invest::setMYears(const vector<int> &t_years) {
	m_years = t_years;
}

const vector<double> &Invest::getMYearEndBalances() const {
	return m_yearEndBalances;
}

void Invest::setMYearEndBalances(const vector<double> &t_yearEndBalances) {
	m_yearEndBalances = t_yearEndBalances;
}

const vector<double> &Invest::getMYearEndEarnedInterests() const {
	return m_yearEndEarnedInterests;
}

void Invest::setMYearEndEarnedInterests(const vector<double> &t_yearEndEarnedInterests) {
	m_yearEndEarnedInterests = t_yearEndEarnedInterests;
}
