
#ifndef AIRGEAD_BANKING_DATA_H_
#define AIRGEAD_BANKING_DATA_H_

#include<vector>

using namespace std;

class Data {
public:
	Data();

	const vector<string> &getMUserPromts() const;

	double getMInitialInvestAmt() const;

	void setMInitialInvestAmt(double t_initialInvestAmt);

	double getMMonthlyDep() const;

	void setMMonthlyDep(double t_monthlyDep);

	double getMAnnualInt() const;

	void setMAnnualInt(double t_annualInt);

	double getMNumYears() const;

	void setMNumYears(double t_numYears);

	void promtuser();

private:
	vector<string> m_userPromts;

	double m_initialInvestAmt;

	double m_monthlyDep;

	double m_annualInt;

	double m_numYears;

	void printHeader();

	vector<double> inputCapture();

	bool enterCheck();
};

#endif
