#ifndef AIRGEAD_BANKING_CALCULATIONS_H
#define AIRGEAD_BANKING_CALCULATIONS_H

#include <vector>
#include "Data.h"
#include "Invest.h"

using namespace std;

class Calculate {

public:
	Calculate();

	Invest calculateAnnualInvestments(Data& data, bool t_monthlyDep = false);

private:
	vector<vector<double>> annualBalWithInt(double t_openAmount, double t_depositAmount, int t_intRate, int t_years);
};

#endif /* CALCULATE_H_ */
